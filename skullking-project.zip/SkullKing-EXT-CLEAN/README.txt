Skull King EXT - Android

Compteur de scores Skull King, sans Rascal.

Bonus séparés par joueur :
- Pirates : +30 chacun
- Sirènes : +20 chacune
- Skull King : +40
- Bonus +10
- Carte 8 de l'extension : +5
- Carte 7 de l'extension : -5

Les bonus sont appliqués uniquement lorsque la mise est exacte.
Le zéro raté vaut -10 x le numéro de manche.
