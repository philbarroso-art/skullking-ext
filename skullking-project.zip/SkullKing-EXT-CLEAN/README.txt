Skull King Score 2.1 - projet Android natif Java

Nouveautés 2.1 :
- suppression de l’option nombre de cartes variable : manches automatiques de 1 à 10
- sauvegarde automatique des parties en cours, y compris la saisie de la manche actuelle
- plusieurs parties en cours peuvent être conservées et reprises plus tard
- bouton Sauvegarder et menu
- bouton Annuler la partie avec confirmation ; une partie annulée ne compte pas au classement
- onglet Classement général
- statistiques par joueur : nombre de parties, points cumulés, record sur une partie et date au format JJ/MM/AAAA
- encart Record à battre parmi tous les joueurs
- seules les parties terminées et enregistrées alimentent le classement

Fonctions existantes conservées : joueurs mémorisés, photos, fond personnalisable, mode Standard / Rascal, extension et bonus.


VERSION 2.2
- Icône Android originale : crâne pirate avec couronne.
- APK partageable : le build debug peut être envoyé et installé sur d'autres téléphones.
- Les fonctions de sauvegarde, reprise, annulation et classement de la version 2.1 sont conservées.
