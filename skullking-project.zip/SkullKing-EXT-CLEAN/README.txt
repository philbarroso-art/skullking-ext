SKULL KING EXT — PROJET ANDROID NATIF PROPRE

Fonctions :
- 2 à 9 joueurs
- noms personnalisés
- 10 manches
- mises et plis
- extension : 8 = +5, 7 = -5
- bonus +5/-5 appliqués seulement si la mise est exacte
- autres bonus manuels
- calcul automatique du score
- contrôle du nombre de plis
- annulation de la dernière manche
- classement final
- aucun Rascal

Projet Android natif Java, sans Flutter, Firebase ni dépendance externe.
Compilation : Gradle / Android Gradle Plugin 8.7.3 / Java 17 / compileSdk 35.
