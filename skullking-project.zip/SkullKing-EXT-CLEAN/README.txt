Skull King EXT 1.1 - Android

Compteur de scores Skull King, sans Rascal.

Bonus séparés par joueur :
- Pirates : +30 chacun
- Sirènes : +20 chacune
- Skull King : +40
- Bonus +10
- Carte 8 de l'extension : +5
- Carte 7 de l'extension : -5
- First Mate Con capturé par le Skull King ou une Sirène : +30
- Davy Jones' Locker : +20 par monstre marin capturé

Les bonus et pénalités ne sont appliqués que si la mise est exacte.
Le zéro raté vaut -10 x le numéro de manche.
Les autres cartes de l'extension n'ajoutent pas de points spécifiques.
