Skull King Score 2.0 - projet Android natif Java

Fonctions principales :
- joueurs mémorisés dans SharedPreferences
- photos facultatives par joueur via sélecteur Android
- sélection rapide des joueurs enregistrés
- fond maritime original + possibilité de choisir une photo de fond personnelle
- voile sombre et panneaux contrastés pour garder les textes lisibles
- mode Standard / score façon Rascal
- extension activable
- bonus Pirates +30, Sirènes +20, Skull King +40, +10
- extension : 8 +5, 7 -5, First Mate Con +30, Davy Jones +20 / monstre
- nombre de cartes variable optionnel
- validation du total des plis, annulation de manche et classement final

Le fond maritime intégré est une illustration originale générée par le code, sans reprendre les ressources graphiques officielles du jeu.
