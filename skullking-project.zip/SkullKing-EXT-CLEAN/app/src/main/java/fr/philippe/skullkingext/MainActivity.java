package fr.philippe.skullkingext;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(10, 24, 39);
    private static final int CARD = Color.rgb(20, 43, 63);
    private static final int GOLD = Color.rgb(226, 183, 80);
    private static final int TEXT = Color.WHITE;
    private static final int MUTED = Color.rgb(176, 190, 197);
    private static final int GREEN = Color.rgb(53, 161, 97);
    private static final int RED = Color.rgb(198, 69, 69);

    private LinearLayout root;
    private int playerCount = 4;
    private int round = 1;
    private final List<String> names = new ArrayList<>();
    private final List<Integer> totals = new ArrayList<>();
    private final List<RoundRecord> history = new ArrayList<>();
    private final List<PlayerInputs> inputRows = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showSetup();
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextColor(TEXT);
        v.setTextSize(sp);
        v.setPadding(dp(8), dp(6), dp(8), dp(6));
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(16);
        b.setAllCaps(false);
        return b;
    }

    private EditText numberInput(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(Color.rgb(130,145,155));
        e.setTextColor(TEXT);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        e.setSingleLine(true);
        e.setGravity(Gravity.CENTER);
        e.setBackgroundColor(Color.rgb(31, 57, 78));
        e.setPadding(dp(6), dp(8), dp(6), dp(8));
        return e;
    }

    private void setContent(LinearLayout content) {
        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true);
        sc.setBackgroundColor(BG);
        sc.addView(content, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(sc);
    }

    private void showSetup() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(24), dp(16), dp(24));
        root.setBackgroundColor(BG);

        TextView title = text("SKULL KING", 30, true);
        title.setTextColor(GOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        TextView sub = text("Compteur de scores + Extension", 18, false);
        sub.setTextColor(MUTED);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub);

        root.addView(space(18));
        TextView playersLabel = text("Nombre de joueurs", 18, true);
        root.addView(playersLabel);

        LinearLayout chooser = new LinearLayout(this);
        chooser.setGravity(Gravity.CENTER_VERTICAL);
        Button minus = button("−");
        TextView count = text(String.valueOf(playerCount), 24, true);
        count.setGravity(Gravity.CENTER);
        Button plus = button("+");
        chooser.addView(minus, new LinearLayout.LayoutParams(0, dp(52), 1));
        chooser.addView(count, new LinearLayout.LayoutParams(0, dp(52), 1));
        chooser.addView(plus, new LinearLayout.LayoutParams(0, dp(52), 1));
        root.addView(chooser);

        LinearLayout nameBox = new LinearLayout(this);
        nameBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(nameBox);
        renderNameInputs(nameBox);

        minus.setOnClickListener(v -> {
            if (playerCount > 2) {
                playerCount--;
                count.setText(String.valueOf(playerCount));
                renderNameInputs(nameBox);
            }
        });
        plus.setOnClickListener(v -> {
            if (playerCount < 9) {
                playerCount++;
                count.setText(String.valueOf(playerCount));
                renderNameInputs(nameBox);
            }
        });

        root.addView(space(12));
        Button start = button("Commencer la partie");
        start.setTextColor(Color.BLACK);
        start.setBackgroundColor(GOLD);
        start.setOnClickListener(v -> startGame(nameBox));
        root.addView(start, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));

        TextView rules = text("Extension : chaque 8 capturé vaut +5 et chaque 7 capturé vaut −5. Ces points ne sont appliqués que si la mise est réussie. Aucun mode Rascal.", 14, false);
        rules.setTextColor(MUTED);
        rules.setPadding(dp(4), dp(20), dp(4), dp(4));
        root.addView(rules);
        setContent(root);
    }

    private void renderNameInputs(LinearLayout box) {
        List<String> old = new ArrayList<>();
        for (int i = 0; i < box.getChildCount(); i++) {
            View v = box.getChildAt(i);
            if (v instanceof EditText) old.add(((EditText) v).getText().toString());
        }
        box.removeAllViews();
        TextView h = text("Noms", 18, true);
        h.setPadding(0, dp(18), 0, dp(8));
        box.addView(h);
        for (int i = 0; i < playerCount; i++) {
            EditText e = new EditText(this);
            e.setTextColor(TEXT);
            e.setHintTextColor(Color.rgb(130,145,155));
            e.setHint("Joueur " + (i + 1));
            e.setSingleLine(true);
            e.setBackgroundColor(Color.rgb(31, 57, 78));
            e.setPadding(dp(12), dp(8), dp(12), dp(8));
            if (i < old.size()) e.setText(old.get(i));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
            lp.setMargins(0, 0, 0, dp(7));
            box.addView(e, lp);
        }
    }

    private void startGame(LinearLayout nameBox) {
        names.clear();
        totals.clear();
        history.clear();
        round = 1;
        int inputIndex = 0;
        for (int i = 0; i < nameBox.getChildCount(); i++) {
            View v = nameBox.getChildAt(i);
            if (v instanceof EditText) {
                String n = ((EditText) v).getText().toString().trim();
                if (n.isEmpty()) n = "Joueur " + (inputIndex + 1);
                names.add(n);
                totals.add(0);
                inputIndex++;
            }
        }
        showRound();
    }

    private void showRound() {
        if (round > 10) {
            showFinal();
            return;
        }
        inputRows.clear();
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(16), dp(12), dp(30));
        root.setBackgroundColor(BG);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView r = text("Manche " + round + " / 10", 26, true);
        r.setTextColor(GOLD);
        top.addView(r, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button scoreBtn = button("Scores");
        scoreBtn.setOnClickListener(v -> showScoreDialog());
        top.addView(scoreBtn, new LinearLayout.LayoutParams(dp(105), dp(48)));
        root.addView(top);

        TextView help = text("Saisis la mise, les plis, puis le nombre de cartes 8 (+5) et 7 (−5) capturées.", 14, false);
        help.setTextColor(MUTED);
        root.addView(help);
        root.addView(space(8));

        for (int i = 0; i < names.size(); i++) {
            root.addView(createPlayerCard(i));
        }

        Button validate = button("Valider la manche");
        validate.setTextColor(Color.BLACK);
        validate.setBackgroundColor(GOLD);
        validate.setOnClickListener(v -> validateRound());
        LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58));
        vlp.setMargins(0, dp(10), 0, dp(8));
        root.addView(validate, vlp);

        if (!history.isEmpty()) {
            Button undo = button("Annuler la dernière manche");
            undo.setOnClickListener(v -> undoLast());
            root.addView(undo, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        }

        setContent(root);
    }

    private View createPlayerCard(int index) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(10), dp(10), dp(10), dp(10));
        card.setBackgroundColor(CARD);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.setMargins(0, 0, 0, dp(10));
        card.setLayoutParams(cp);

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView n = text(names.get(index), 19, true);
        TextView total = text("Total : " + totals.get(index), 16, true);
        total.setTextColor(GOLD);
        total.setGravity(Gravity.END);
        head.addView(n, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        head.addView(total, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        card.addView(head);

        LinearLayout labels = new LinearLayout(this);
        String[] ls = {"Mise", "Plis", "8 (+5)", "7 (−5)"};
        for (String s : ls) {
            TextView tv = text(s, 12, true);
            tv.setTextColor(MUTED);
            tv.setGravity(Gravity.CENTER);
            labels.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        }
        card.addView(labels);

        LinearLayout fields = new LinearLayout(this);
        EditText bid = numberInput("0");
        EditText tricks = numberInput("0");
        EditText plus5 = numberInput("0");
        EditText minus5 = numberInput("0");
        fields.addView(bid, weightedField());
        fields.addView(tricks, weightedField());
        fields.addView(plus5, weightedField());
        fields.addView(minus5, weightedField());
        card.addView(fields);

        TextView otherLabel = text("Autres bonus (points)", 12, true);
        otherLabel.setTextColor(MUTED);
        otherLabel.setPadding(dp(4), dp(8), dp(4), dp(3));
        card.addView(otherLabel);
        EditText other = numberInput("0");
        card.addView(other, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        inputRows.add(new PlayerInputs(bid, tricks, plus5, minus5, other));
        return card;
    }

    private LinearLayout.LayoutParams weightedField() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(48), 1);
        p.setMargins(dp(2), 0, dp(2), 0);
        return p;
    }

    private int val(EditText e) {
        String s = e.getText().toString().trim();
        if (s.isEmpty() || s.equals("-")) return 0;
        try { return Integer.parseInt(s); }
        catch (Exception ex) { return 0; }
    }

    private void validateRound() {
        List<Integer> bids = new ArrayList<>();
        List<Integer> tricks = new ArrayList<>();
        List<Integer> p5 = new ArrayList<>();
        List<Integer> m5 = new ArrayList<>();
        List<Integer> other = new ArrayList<>();
        int totalTricks = 0;

        for (PlayerInputs p : inputRows) {
            int b = val(p.bid);
            int t = val(p.tricks);
            int a = val(p.plus5);
            int m = val(p.minus5);
            int o = val(p.otherBonus);
            if (b < 0 || b > round || t < 0 || t > round || a < 0 || m < 0) {
                toast("Valeur impossible dans la manche " + round);
                return;
            }
            bids.add(b); tricks.add(t); p5.add(a); m5.add(m); other.add(o);
            totalTricks += t;
        }

        if (totalTricks != round) {
            new AlertDialog.Builder(this)
                .setTitle("Nombre de plis")
                .setMessage("Tu as saisi " + totalTricks + " plis, mais la manche " + round + " doit contenir " + round + " pli" + (round > 1 ? "s" : "") + ".")
                .setPositiveButton("Corriger", null)
                .setNegativeButton("Valider quand même", (d,w) -> applyRound(bids, tricks, p5, m5, other))
                .show();
            return;
        }
        applyRound(bids, tricks, p5, m5, other);
    }

    private void applyRound(List<Integer> bids, List<Integer> tricks, List<Integer> p5, List<Integer> m5, List<Integer> other) {
        List<Integer> deltas = new ArrayList<>();
        for (int i = 0; i < names.size(); i++) {
            int b = bids.get(i);
            int t = tricks.get(i);
            int delta;
            boolean exact = b == t;
            if (b == 0) {
                delta = exact ? 10 * round : -10 * t;
            } else if (exact) {
                delta = 20 * b;
            } else {
                delta = -10 * Math.abs(b - t);
            }
            if (exact) {
                delta += (p5.get(i) * 5) - (m5.get(i) * 5) + other.get(i);
            }
            totals.set(i, totals.get(i) + delta);
            deltas.add(delta);
        }
        history.add(new RoundRecord(round, deltas));
        round++;
        showRound();
    }

    private void undoLast() {
        if (history.isEmpty()) return;
        RoundRecord rec = history.remove(history.size() - 1);
        for (int i = 0; i < totals.size(); i++) totals.set(i, totals.get(i) - rec.deltas.get(i));
        round = rec.roundNumber;
        showRound();
    }

    private void showScoreDialog() {
        StringBuilder sb = new StringBuilder();
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < names.size(); i++) order.add(i);
        Collections.sort(order, (a,b) -> Integer.compare(totals.get(b), totals.get(a)));
        for (int rank = 0; rank < order.size(); rank++) {
            int i = order.get(rank);
            sb.append(rank + 1).append(". ").append(names.get(i)).append(" — ").append(totals.get(i)).append(" pts\n");
        }
        new AlertDialog.Builder(this).setTitle("Classement").setMessage(sb.toString()).setPositiveButton("OK", null).show();
    }

    private void showFinal() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(28), dp(16), dp(28));
        root.setBackgroundColor(BG);
        TextView t = text("Partie terminée", 30, true);
        t.setTextColor(GOLD);
        t.setGravity(Gravity.CENTER);
        root.addView(t);

        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < names.size(); i++) order.add(i);
        Collections.sort(order, (a,b) -> Integer.compare(totals.get(b), totals.get(a)));
        for (int rank = 0; rank < order.size(); rank++) {
            int i = order.get(rank);
            TextView row = text((rank + 1) + ".  " + names.get(i) + "     " + totals.get(i) + " pts", rank == 0 ? 23 : 19, true);
            if (rank == 0) row.setTextColor(GOLD);
            row.setPadding(dp(10), dp(14), dp(10), dp(14));
            root.addView(row);
        }

        root.addView(space(18));
        Button again = button("Nouvelle partie");
        again.setBackgroundColor(GOLD);
        again.setTextColor(Color.BLACK);
        again.setOnClickListener(v -> showSetup());
        root.addView(again, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));

        if (!history.isEmpty()) {
            Button undo = button("Revenir à la manche 10");
            undo.setOnClickListener(v -> undoLast());
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
            lp.setMargins(0, dp(8), 0, 0);
            root.addView(undo, lp);
        }
        setContent(root);
    }

    private View space(int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h)));
        return v;
    }

    private int dp(int n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private static class PlayerInputs {
        final EditText bid, tricks, plus5, minus5, otherBonus;
        PlayerInputs(EditText bid, EditText tricks, EditText plus5, EditText minus5, EditText otherBonus) {
            this.bid = bid; this.tricks = tricks; this.plus5 = plus5; this.minus5 = minus5; this.otherBonus = otherBonus;
        }
    }

    private static class RoundRecord {
        final int roundNumber;
        final List<Integer> deltas;
        RoundRecord(int roundNumber, List<Integer> deltas) {
            this.roundNumber = roundNumber; this.deltas = new ArrayList<>(deltas);
        }
    }
}
