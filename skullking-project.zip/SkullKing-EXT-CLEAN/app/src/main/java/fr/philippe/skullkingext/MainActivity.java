package fr.philippe.skullkingext;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQUEST_PLAYER_PHOTO = 1001;
    private static final int REQUEST_BACKGROUND = 1002;

    private static final int GOLD = Color.rgb(232, 190, 88);
    private static final int TEXT = Color.WHITE;
    private static final int MUTED = Color.rgb(220, 228, 232);
    private static final int GREEN = Color.rgb(46, 204, 142);
    private static final int RED = Color.rgb(235, 90, 90);
    private static final int NAVY = Color.rgb(8, 24, 36);
    private static final int PANEL = Color.argb(218, 10, 34, 48);
    private static final int PANEL_LIGHT = Color.argb(232, 240, 246, 247);
    private static final int PANEL_DARK = Color.argb(225, 15, 47, 61);

    private final List<Player> savedPlayers = new ArrayList<>();
    private final Set<String> selectedIds = new HashSet<>();
    private final List<Player> gamePlayers = new ArrayList<>();
    private final List<Double> totals = new ArrayList<>();
    private final List<RoundRecord> history = new ArrayList<>();
    private final List<PlayerInputs> inputRows = new ArrayList<>();

    private SharedPreferences prefs;
    private boolean rascalMode = false;
    private boolean extensionMode = true;
    private boolean variableCards = false;
    private String backgroundUri = "";
    private int round = 1;
    private int pendingPhotoPlayerIndex = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(5, 20, 30));
        prefs = getSharedPreferences("skullking_prefs_v2", MODE_PRIVATE);
        loadState();
        showHome();
    }

    // ---------------------------------------------------------------------
    // Persistence
    // ---------------------------------------------------------------------

    private void loadState() {
        rascalMode = prefs.getBoolean("rascal", false);
        extensionMode = prefs.getBoolean("extension", true);
        variableCards = prefs.getBoolean("variable_cards", false);
        backgroundUri = prefs.getString("background_uri", "");

        savedPlayers.clear();
        try {
            JSONArray arr = new JSONArray(prefs.getString("players", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                savedPlayers.add(new Player(
                        o.optString("id", UUID.randomUUID().toString()),
                        o.optString("name", "Joueur"),
                        o.optString("photo", "")));
            }
        } catch (Exception ignored) {
        }

        if (savedPlayers.isEmpty()) {
            savedPlayers.add(new Player(UUID.randomUUID().toString(), "Phil", ""));
            savedPlayers.add(new Player(UUID.randomUUID().toString(), "Joueur 2", ""));
            savePlayers();
        }

        selectedIds.clear();
        selectedIds.addAll(prefs.getStringSet("selected_ids", new HashSet<>()));
        // Remove stale ids.
        Set<String> existing = new HashSet<>();
        for (Player p : savedPlayers) existing.add(p.id);
        selectedIds.retainAll(existing);
    }

    private void savePlayers() {
        JSONArray arr = new JSONArray();
        try {
            for (Player p : savedPlayers) {
                JSONObject o = new JSONObject();
                o.put("id", p.id);
                o.put("name", p.name);
                o.put("photo", p.photoUri);
                arr.put(o);
            }
        } catch (Exception ignored) {
        }
        prefs.edit().putString("players", arr.toString()).apply();
    }

    private void saveOptions() {
        prefs.edit()
                .putBoolean("rascal", rascalMode)
                .putBoolean("extension", extensionMode)
                .putBoolean("variable_cards", variableCards)
                .putString("background_uri", backgroundUri)
                .putStringSet("selected_ids", new HashSet<>(selectedIds))
                .apply();
    }

    // ---------------------------------------------------------------------
    // Background / common UI
    // ---------------------------------------------------------------------

    private FrameLayout baseScreen() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(NAVY);

        if (backgroundUri != null && !backgroundUri.isEmpty()) {
            ImageView bg = new ImageView(this);
            bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
            try {
                bg.setImageURI(Uri.parse(backgroundUri));
                frame.addView(bg, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
            } catch (Exception ex) {
                backgroundUri = "";
                saveOptions();
                frame.addView(new SeaBackgroundView(this), new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
            }
        } else {
            frame.addView(new SeaBackgroundView(this), new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
        }

        View veil = new View(this);
        veil.setBackgroundColor(Color.argb(92, 0, 12, 20));
        frame.addView(veil, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        return frame;
    }

    private void setScreen(LinearLayout content) {
        FrameLayout frame = baseScreen();
        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true);
        sc.addView(content, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        frame.addView(sc, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(frame);
    }

    private TextView tv(String s, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextColor(TEXT);
        v.setTextSize(sp);
        v.setPadding(dp(8), dp(6), dp(8), dp(6));
        if (bold) v.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        return v;
    }

    private Button btn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackground(rounded(Color.argb(235, 24, 78, 95), 16, Color.argb(120, 255, 255, 255), 1));
        b.setPadding(dp(8), dp(5), dp(8), dp(5));
        return b;
    }

    private GradientDrawable rounded(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    private View spacer(int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h)));
        return v;
    }

    // ---------------------------------------------------------------------
    // Home screen
    // ---------------------------------------------------------------------

    private void showHome() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(18), dp(14), dp(28));

        TextView title = tv("SKULL KING", 32, true);
        title.setGravity(Gravity.CENTER);
        title.setTextColor(GOLD);
        root.addView(title);

        TextView subtitle = tv("Marqueur de score personnel", 16, false);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setTextColor(MUTED);
        root.addView(subtitle);
        root.addView(spacer(14));

        LinearLayout playersPanel = panel();
        LinearLayout playersHead = new LinearLayout(this);
        playersHead.setGravity(Gravity.CENTER_VERTICAL);
        TextView ph = tv("Joueurs", 27, true);
        ph.setTextColor(Color.WHITE);
        playersHead.addView(ph, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button create = btn("+ Créer");
        Button manage = btn("Gérer");
        playersHead.addView(create, new LinearLayout.LayoutParams(dp(102), dp(48)));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(dp(88), dp(48));
        mp.setMargins(dp(6), 0, 0, 0);
        playersHead.addView(manage, mp);
        playersPanel.addView(playersHead);

        TextView hint = tv("Touchez les joueurs pour les sélectionner. Appui long = modifier / photo / supprimer.", 13, false);
        hint.setTextColor(MUTED);
        playersPanel.addView(hint);

        GridLayout playerGrid = new GridLayout(this);
        playerGrid.setColumnCount(3);
        playerGrid.setPadding(0, dp(6), 0, dp(4));
        playersPanel.addView(playerGrid);
        root.addView(playersPanel);

        Button start = btn("Sélectionnez au moins 2 joueurs");
        start.setTextSize(18);
        start.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(62));
        slp.setMargins(0, dp(12), 0, 0);
        root.addView(start, slp);

        Runnable refreshPlayers = () -> renderPlayerGrid(playerGrid, start);
        renderPlayerGrid(playerGrid, start);

        create.setOnClickListener(v -> showCreatePlayerDialog(refreshPlayers));
        manage.setOnClickListener(v -> showManagePlayers());
        start.setOnClickListener(v -> {
            if (selectedIds.size() < 2) {
                toast("Sélectionne au moins 2 joueurs.");
                return;
            }
            startGame();
        });

        root.addView(spacer(14));
        LinearLayout opts = panel();
        TextView oh = tv("Variantes", 27, true);
        opts.addView(oh);

        Switch rascal = new Switch(this);
        rascal.setText("Score façon Rascal");
        rascal.setTextColor(TEXT);
        rascal.setTextSize(18);
        rascal.setChecked(rascalMode);
        rascal.setPadding(dp(8), dp(8), dp(8), dp(8));
        opts.addView(rascal);

        TextView rascalHelp = tv("Rascal : exact = 100 %, erreur de 1 = 50 %, erreur de 2 ou plus = 0. Les bonus suivent la même règle.", 13, false);
        rascalHelp.setTextColor(MUTED);
        opts.addView(rascalHelp);

        Switch ext = new Switch(this);
        ext.setText("Extension complète");
        ext.setTextColor(TEXT);
        ext.setTextSize(18);
        ext.setChecked(extensionMode);
        ext.setPadding(dp(8), dp(8), dp(8), dp(8));
        opts.addView(ext);

        Switch variable = new Switch(this);
        variable.setText("Nombre de cartes variable");
        variable.setTextColor(TEXT);
        variable.setTextSize(18);
        variable.setChecked(variableCards);
        variable.setPadding(dp(8), dp(8), dp(8), dp(8));
        opts.addView(variable);

        TextView varHelp = tv("Si activé, l'appli te demande le nombre de cartes de chaque manche avant de saisir les scores.", 13, false);
        varHelp.setTextColor(MUTED);
        opts.addView(varHelp);

        rascal.setOnCheckedChangeListener((b, checked) -> {
            rascalMode = checked;
            saveOptions();
        });
        ext.setOnCheckedChangeListener((b, checked) -> {
            extensionMode = checked;
            saveOptions();
        });
        variable.setOnCheckedChangeListener((b, checked) -> {
            variableCards = checked;
            saveOptions();
        });
        root.addView(opts);

        root.addView(spacer(14));
        LinearLayout bgPanel = panel();
        bgPanel.addView(tv("Fond", 22, true));
        TextView bgHelp = tv("Le fond maritime est fourni. Tu peux aussi choisir une photo de ton téléphone ; un voile sombre garde toujours les écritures lisibles.", 13, false);
        bgHelp.setTextColor(MUTED);
        bgPanel.addView(bgHelp);

        LinearLayout bgButtons = new LinearLayout(this);
        Button chooseBg = btn("Choisir une photo");
        Button resetBg = btn("Fond maritime");
        bgButtons.addView(chooseBg, new LinearLayout.LayoutParams(0, dp(50), 1));
        LinearLayout.LayoutParams rbp = new LinearLayout.LayoutParams(0, dp(50), 1);
        rbp.setMargins(dp(6), 0, 0, 0);
        bgButtons.addView(resetBg, rbp);
        bgPanel.addView(bgButtons);
        root.addView(bgPanel);

        chooseBg.setOnClickListener(v -> chooseBackground());
        resetBg.setOnClickListener(v -> {
            backgroundUri = "";
            saveOptions();
            showHome();
        });

        setScreen(root);
    }

    private LinearLayout panel() {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(10), dp(10), dp(10), dp(10));
        p.setBackground(rounded(PANEL, 18, Color.argb(95, 255, 255, 255), 1));
        return p;
    }

    private void renderPlayerGrid(GridLayout grid, Button start) {
        grid.removeAllViews();
        for (int i = 0; i < savedPlayers.size(); i++) {
            final int index = i;
            Player p = savedPlayers.get(i);
            boolean selected = selectedIds.contains(p.id);
            LinearLayout chip = new LinearLayout(this);
            chip.setOrientation(LinearLayout.VERTICAL);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(5), dp(7), dp(5), dp(7));
            chip.setBackground(rounded(
                    selected ? Color.argb(238, 39, 137, 115) : Color.argb(232, 235, 241, 242),
                    14,
                    selected ? GOLD : Color.argb(110, 255, 255, 255),
                    selected ? 2 : 1));

            ImageView avatar = avatarView(p, dp(54));
            chip.addView(avatar, new LinearLayout.LayoutParams(dp(54), dp(54)));

            TextView name = tv((selected ? "✓ " : "") + p.name, 15, true);
            name.setTextColor(selected ? Color.WHITE : Color.rgb(15, 28, 34));
            name.setGravity(Gravity.CENTER);
            name.setMaxLines(1);
            chip.addView(name, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));

            chip.setOnClickListener(v -> {
                if (selectedIds.contains(p.id)) selectedIds.remove(p.id);
                else selectedIds.add(p.id);
                saveOptions();
                renderPlayerGrid(grid, start);
            });
            chip.setOnLongClickListener(v -> {
                showPlayerActions(index, () -> renderPlayerGrid(grid, start));
                return true;
            });

            GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
            gp.width = 0;
            gp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            gp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            gp.setMargins(dp(3), dp(3), dp(3), dp(3));
            grid.addView(chip, gp);
        }

        if (selectedIds.size() >= 2) {
            start.setText("Commencer • " + selectedIds.size() + " joueurs");
            start.setTextColor(Color.rgb(8, 27, 35));
            start.setBackground(rounded(GOLD, 16, Color.argb(120, 255, 255, 255), 1));
        } else {
            start.setText("Sélectionnez au moins 2 joueurs");
            start.setTextColor(Color.WHITE);
            start.setBackground(rounded(Color.argb(215, 69, 83, 88), 16, Color.argb(90, 255, 255, 255), 1));
        }
    }

    private ImageView avatarView(Player p, int size) {
        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setBackground(rounded(Color.argb(230, 17, 55, 70), size / 2, GOLD, 2));
        iv.setClipToOutline(true);
        if (p.photoUri != null && !p.photoUri.isEmpty()) {
            try {
                iv.setImageURI(Uri.parse(p.photoUri));
            } catch (Exception ignored) {
            }
        }
        if (iv.getDrawable() == null) {
            // A simple text initial is drawn by layering a TextView where needed; here we keep the nautical disk.
            iv.setImageResource(android.R.drawable.ic_menu_camera);
            iv.setColorFilter(Color.WHITE);
            iv.setPadding(size / 5, size / 5, size / 5, size / 5);
        }
        return iv;
    }

    private void showCreatePlayerDialog(Runnable after) {
        final EditText input = new EditText(this);
        input.setHint("Nom du joueur");
        input.setSingleLine(true);
        input.setPadding(dp(16), dp(10), dp(16), dp(10));

        new AlertDialog.Builder(this)
                .setTitle("Créer un joueur")
                .setView(input)
                .setPositiveButton("Créer", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) name = "Joueur " + (savedPlayers.size() + 1);
                    Player p = new Player(UUID.randomUUID().toString(), name, "");
                    savedPlayers.add(p);
                    selectedIds.add(p.id);
                    savePlayers();
                    saveOptions();
                    if (after != null) after.run();
                })
                .setNegativeButton("Annuler", null)
                .show();
    }

    private void showPlayerActions(int index, Runnable after) {
        if (index < 0 || index >= savedPlayers.size()) return;
        Player p = savedPlayers.get(index);
        String[] items = new String[]{"Modifier le nom", "Choisir / changer la photo", "Retirer la photo", "Supprimer le joueur"};
        new AlertDialog.Builder(this)
                .setTitle(p.name)
                .setItems(items, (d, which) -> {
                    if (which == 0) renamePlayer(index, after);
                    else if (which == 1) choosePlayerPhoto(index);
                    else if (which == 2) {
                        p.photoUri = "";
                        savePlayers();
                        if (after != null) after.run();
                    } else if (which == 3) confirmDeletePlayer(index, after);
                })
                .show();
    }

    private void renamePlayer(int index, Runnable after) {
        Player p = savedPlayers.get(index);
        EditText input = new EditText(this);
        input.setText(p.name);
        input.setSelection(input.getText().length());
        input.setSingleLine(true);
        new AlertDialog.Builder(this)
                .setTitle("Modifier le nom")
                .setView(input)
                .setPositiveButton("Enregistrer", (d, w) -> {
                    String n = input.getText().toString().trim();
                    if (!n.isEmpty()) p.name = n;
                    savePlayers();
                    if (after != null) after.run();
                })
                .setNegativeButton("Annuler", null)
                .show();
    }

    private void confirmDeletePlayer(int index, Runnable after) {
        Player p = savedPlayers.get(index);
        new AlertDialog.Builder(this)
                .setTitle("Supprimer " + p.name + " ?")
                .setMessage("Le joueur sera retiré de la liste enregistrée.")
                .setPositiveButton("Supprimer", (d, w) -> {
                    selectedIds.remove(p.id);
                    savedPlayers.remove(index);
                    savePlayers();
                    saveOptions();
                    if (after != null) after.run();
                })
                .setNegativeButton("Annuler", null)
                .show();
    }

    private void showManagePlayers() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(18), dp(14), dp(28));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        Button back = btn("← Retour");
        head.addView(back, new LinearLayout.LayoutParams(dp(100), dp(48)));
        TextView title = tv("Gérer les joueurs", 25, true);
        title.setGravity(Gravity.CENTER);
        head.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1));
        root.addView(head);
        root.addView(spacer(10));

        for (int i = 0; i < savedPlayers.size(); i++) {
            final int index = i;
            Player p = savedPlayers.get(i);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(9), dp(9), dp(9), dp(9));
            row.setBackground(rounded(PANEL, 16, Color.argb(90, 255, 255, 255), 1));

            row.addView(avatarView(p, dp(58)), new LinearLayout.LayoutParams(dp(58), dp(58)));
            TextView name = tv(p.name, 19, true);
            row.addView(name, new LinearLayout.LayoutParams(0, dp(58), 1));
            Button edit = btn("Modifier");
            row.addView(edit, new LinearLayout.LayoutParams(dp(98), dp(48)));
            edit.setOnClickListener(v -> showPlayerActions(index, this::showManagePlayers));

            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.setMargins(0, 0, 0, dp(8));
            root.addView(row, rlp);
        }

        Button add = btn("+ Ajouter un joueur");
        add.setBackground(rounded(GOLD, 16, Color.argb(100, 255, 255, 255), 1));
        add.setTextColor(Color.rgb(8, 27, 35));
        add.setOnClickListener(v -> showCreatePlayerDialog(this::showManagePlayers));
        root.addView(add, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));

        back.setOnClickListener(v -> showHome());
        setScreen(root);
    }

    private void choosePlayerPhoto(int index) {
        pendingPhotoPlayerIndex = index;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQUEST_PLAYER_PHOTO);
    }

    private void chooseBackground() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQUEST_BACKGROUND);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
        }

        if (requestCode == REQUEST_PLAYER_PHOTO) {
            if (pendingPhotoPlayerIndex >= 0 && pendingPhotoPlayerIndex < savedPlayers.size()) {
                savedPlayers.get(pendingPhotoPlayerIndex).photoUri = uri.toString();
                savePlayers();
            }
            pendingPhotoPlayerIndex = -1;
            showHome();
        } else if (requestCode == REQUEST_BACKGROUND) {
            backgroundUri = uri.toString();
            saveOptions();
            showHome();
        }
    }

    // ---------------------------------------------------------------------
    // Game
    // ---------------------------------------------------------------------

    private void startGame() {
        gamePlayers.clear();
        for (Player p : savedPlayers) {
            if (selectedIds.contains(p.id)) gamePlayers.add(p.copy());
        }
        if (gamePlayers.size() < 2) {
            toast("Sélectionne au moins 2 joueurs.");
            return;
        }
        totals.clear();
        for (int i = 0; i < gamePlayers.size(); i++) totals.add(0.0);
        history.clear();
        round = 1;
        if (variableCards) askCardsForRound();
        else showRound(round);
    }

    private void askCardsForRound() {
        if (round > 10) {
            showFinal();
            return;
        }
        final EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        input.setText(String.valueOf(round));
        input.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this)
                .setTitle("Manche " + round)
                .setMessage("Combien de cartes sont distribuées à chaque joueur ?")
                .setView(input)
                .setCancelable(false)
                .setPositiveButton("Continuer", (d, w) -> {
                    int cards = parseInt(input.getText().toString(), round);
                    if (cards < 1) cards = round;
                    showRound(cards);
                })
                .setNegativeButton("Quitter", (d, w) -> showHome())
                .show();
    }

    private void showRound(int cardsThisRound) {
        if (round > 10) {
            showFinal();
            return;
        }
        inputRows.clear();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(10), dp(14), dp(10), dp(28));

        LinearLayout top = panel();
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView roundTitle = tv("Manche " + round + " / 10", 26, true);
        roundTitle.setTextColor(GOLD);
        titleRow.addView(roundTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button scores = btn("Scores");
        titleRow.addView(scores, new LinearLayout.LayoutParams(dp(95), dp(48)));
        top.addView(titleRow);

        String mode = rascalMode ? "Rascal" : "Standard";
        TextView modeText = tv(mode + " • " + cardsThisRound + " carte" + (cardsThisRound > 1 ? "s" : "") + " • " + (extensionMode ? "Extension ON" : "Extension OFF"), 14, true);
        modeText.setTextColor(MUTED);
        top.addView(modeText);
        root.addView(top);

        root.addView(spacer(9));
        for (int i = 0; i < gamePlayers.size(); i++) {
            root.addView(createScoreCard(i, cardsThisRound));
        }

        Button validate = btn("Valider la manche");
        validate.setTextSize(18);
        validate.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        validate.setTextColor(Color.rgb(8, 27, 35));
        validate.setBackground(rounded(GOLD, 16, Color.argb(120, 255, 255, 255), 1));
        LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(60));
        vlp.setMargins(0, dp(4), 0, dp(8));
        root.addView(validate, vlp);

        if (!history.isEmpty()) {
            Button undo = btn("Annuler la dernière manche");
            undo.setOnClickListener(v -> undoLast());
            root.addView(undo, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        }

        scores.setOnClickListener(v -> showScoreDialog());
        validate.setOnClickListener(v -> validateRound(cardsThisRound));
        setScreen(root);
    }

    private View createScoreCard(int index, int maxValue) {
        Player p = gamePlayers.get(index);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(10), dp(10), dp(10), dp(11));
        card.setBackground(rounded(PANEL_DARK, 18, Color.argb(110, 255, 255, 255), 1));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.setMargins(0, 0, 0, dp(10));
        card.setLayoutParams(cp);

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(avatarView(p, dp(48)), new LinearLayout.LayoutParams(dp(48), dp(48)));
        TextView name = tv(p.name, 20, true);
        head.addView(name, new LinearLayout.LayoutParams(0, dp(50), 1));
        TextView total = tv(formatScore(totals.get(index)) + " pts", 17, true);
        total.setTextColor(GOLD);
        total.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        head.addView(total, new LinearLayout.LayoutParams(dp(105), dp(50)));
        card.addView(head);

        LinearLayout counters = new LinearLayout(this);
        IntCounter bid = addStepper(counters, "Offre", maxValue);
        IntCounter tricks = addStepper(counters, "Plis gagnés", maxValue);
        card.addView(counters);

        TextView bonusTitle = tv("POINTS BONUS", 16, true);
        bonusTitle.setTextColor(GOLD);
        bonusTitle.setGravity(Gravity.CENTER);
        bonusTitle.setPadding(dp(4), dp(10), dp(4), dp(5));
        card.addView(bonusTitle);

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        BonusCounter pirates = addBonusTile(grid, "🏴‍☠️ Pirates", "+30", 30);
        BonusCounter sirens = addBonusTile(grid, "🧜 Sirènes", "+20", 20);
        BonusCounter skull = addBonusTile(grid, "☠ Skull King", "+40", 40);
        BonusCounter plus10 = addBonusTile(grid, "🪙 Bonus", "+10", 10);

        BonusCounter plus5 = null;
        BonusCounter minus5 = null;
        BonusCounter firstMate = null;
        BonusCounter davyJones = null;
        if (extensionMode) {
            plus5 = addBonusTile(grid, "8 • bonus", "+5", 5);
            minus5 = addBonusTile(grid, "7 • malus", "−5", -5);
            firstMate = addBonusTile(grid, "⚓ First Mate Con", "+30", 30);
            davyJones = addBonusTile(grid, "🌊 Davy Jones", "+20 / monstre", 20);
        }
        card.addView(grid);

        inputRows.add(new PlayerInputs(bid, tricks, pirates, sirens, skull, plus10, plus5, minus5, firstMate, davyJones));
        return card;
    }

    private IntCounter addStepper(LinearLayout parent, String label, int maxValue) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(4), dp(4), dp(4), dp(4));
        TextView l = tv(label, 14, true);
        l.setTextColor(MUTED);
        l.setGravity(Gravity.CENTER);
        box.addView(l);

        LinearLayout row = new LinearLayout(this);
        Button minus = btn("−");
        TextView value = tv("0", 22, true);
        value.setGravity(Gravity.CENTER);
        Button plus = btn("+");
        row.addView(minus, new LinearLayout.LayoutParams(0, dp(46), 1));
        row.addView(value, new LinearLayout.LayoutParams(0, dp(46), 1));
        row.addView(plus, new LinearLayout.LayoutParams(0, dp(46), 1));
        box.addView(row, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));

        IntCounter counter = new IntCounter(value, maxValue);
        minus.setOnClickListener(v -> counter.dec());
        plus.setOnClickListener(v -> counter.inc());
        parent.addView(box, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        return counter;
    }

    private BonusCounter addBonusTile(GridLayout grid, String label, String ptsLabel, int pointValue) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setPadding(dp(6), dp(7), dp(6), dp(7));
        tile.setBackground(rounded(Color.argb(225, 235, 243, 244), 13, Color.argb(90, 255, 255, 255), 1));

        TextView title = tv(label, 14, true);
        title.setTextColor(Color.rgb(9, 30, 38));
        title.setGravity(Gravity.CENTER);
        tile.addView(title);

        TextView pts = tv(ptsLabel, 13, true);
        pts.setGravity(Gravity.CENTER);
        pts.setTextColor(pointValue < 0 ? RED : Color.rgb(20, 125, 78));
        tile.addView(pts);

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER);
        Button minus = btn("−");
        TextView value = tv("0", 20, true);
        value.setTextColor(Color.rgb(10, 28, 34));
        value.setGravity(Gravity.CENTER);
        Button plus = btn("+");
        controls.addView(minus, new LinearLayout.LayoutParams(0, dp(42), 1));
        controls.addView(value, new LinearLayout.LayoutParams(0, dp(42), 1));
        controls.addView(plus, new LinearLayout.LayoutParams(0, dp(42), 1));
        tile.addView(controls);

        BonusCounter c = new BonusCounter(value, pointValue);
        minus.setOnClickListener(v -> c.dec());
        plus.setOnClickListener(v -> c.inc());

        GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
        gp.width = 0;
        gp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        gp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        gp.setMargins(dp(3), dp(3), dp(3), dp(3));
        grid.addView(tile, gp);
        return c;
    }

    private void validateRound(int cardsThisRound) {
        int totalTricks = 0;
        for (PlayerInputs p : inputRows) totalTricks += p.tricks.value;

        if (totalTricks != cardsThisRound) {
            new AlertDialog.Builder(this)
                    .setTitle("Nombre de plis")
                    .setMessage("Tu as saisi " + totalTricks + " plis, alors que cette manche contient " + cardsThisRound + " plis.")
                    .setPositiveButton("Corriger", null)
                    .setNegativeButton("Valider quand même", (d, w) -> applyRound(cardsThisRound))
                    .show();
            return;
        }
        applyRound(cardsThisRound);
    }

    private void applyRound(int cardsThisRound) {
        List<Double> deltas = new ArrayList<>();

        for (int i = 0; i < gamePlayers.size(); i++) {
            PlayerInputs p = inputRows.get(i);
            int bid = p.bid.value;
            int tricks = p.tricks.value;
            int diff = Math.abs(bid - tricks);
            double bonus = p.totalBonus();
            double delta;

            if (rascalMode) {
                double factor = diff == 0 ? 1.0 : (diff == 1 ? 0.5 : 0.0);
                double potential = 10.0 * cardsThisRound;
                delta = potential * factor + bonus * factor;
            } else {
                boolean exact = diff == 0;
                if (bid == 0) {
                    delta = exact ? 10.0 * cardsThisRound : -10.0 * cardsThisRound;
                } else if (exact) {
                    delta = 20.0 * bid;
                } else {
                    delta = -10.0 * diff;
                }
                if (exact) delta += bonus;
            }

            totals.set(i, totals.get(i) + delta);
            deltas.add(delta);
        }

        history.add(new RoundRecord(round, cardsThisRound, deltas));
        round++;
        if (round > 10) showFinal();
        else if (variableCards) askCardsForRound();
        else showRound(round);
    }

    private void undoLast() {
        if (history.isEmpty()) return;
        RoundRecord rec = history.remove(history.size() - 1);
        for (int i = 0; i < totals.size(); i++) {
            totals.set(i, totals.get(i) - rec.deltas.get(i));
        }
        round = rec.roundNumber;
        showRound(rec.cardsThisRound);
    }

    private void showScoreDialog() {
        StringBuilder sb = new StringBuilder();
        List<Integer> order = sortedIndexes();
        for (int rank = 0; rank < order.size(); rank++) {
            int i = order.get(rank);
            sb.append(rank + 1).append(". ")
                    .append(gamePlayers.get(i).name)
                    .append(" — ")
                    .append(formatScore(totals.get(i)))
                    .append(" pts\n");
        }
        new AlertDialog.Builder(this)
                .setTitle("Classement")
                .setMessage(sb.toString())
                .setPositiveButton("OK", null)
                .show();
    }

    private List<Integer> sortedIndexes() {
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < gamePlayers.size(); i++) order.add(i);
        Collections.sort(order, (a, b) -> Double.compare(totals.get(b), totals.get(a)));
        return order;
    }

    private void showFinal() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(26), dp(14), dp(30));

        LinearLayout panel = panel();
        TextView t = tv("Partie terminée", 30, true);
        t.setTextColor(GOLD);
        t.setGravity(Gravity.CENTER);
        panel.addView(t);

        List<Integer> order = sortedIndexes();
        for (int rank = 0; rank < order.size(); rank++) {
            int i = order.get(rank);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(8), dp(8), dp(8), dp(8));
            row.addView(avatarView(gamePlayers.get(i), dp(48)), new LinearLayout.LayoutParams(dp(48), dp(48)));
            TextView line = tv((rank + 1) + ". " + gamePlayers.get(i).name, rank == 0 ? 21 : 18, true);
            if (rank == 0) line.setTextColor(GOLD);
            row.addView(line, new LinearLayout.LayoutParams(0, dp(52), 1));
            TextView score = tv(formatScore(totals.get(i)) + " pts", 18, true);
            score.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
            if (rank == 0) score.setTextColor(GOLD);
            row.addView(score, new LinearLayout.LayoutParams(dp(110), dp(52)));
            panel.addView(row);
        }
        root.addView(panel);
        root.addView(spacer(12));

        Button again = btn("Nouvelle partie");
        again.setBackground(rounded(GOLD, 16, Color.argb(100, 255, 255, 255), 1));
        again.setTextColor(Color.rgb(8, 27, 35));
        again.setTextSize(18);
        again.setOnClickListener(v -> showHome());
        root.addView(again, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));

        if (!history.isEmpty()) {
            Button undo = btn("Revenir à la dernière manche");
            LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
            ulp.setMargins(0, dp(8), 0, 0);
            root.addView(undo, ulp);
            undo.setOnClickListener(v -> undoLast());
        }
        setScreen(root);
    }

    // ---------------------------------------------------------------------
    // Helpers / models
    // ---------------------------------------------------------------------

    private int parseInt(String s, int fallback) {
        try { return Integer.parseInt(s.trim()); }
        catch (Exception e) { return fallback; }
    }

    private String formatScore(double value) {
        if (Math.abs(value - Math.rint(value)) < 0.00001) {
            return String.valueOf((long) Math.rint(value));
        }
        return String.format(Locale.FRANCE, "%.1f", value);
    }

    private int dp(int n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private static class Player {
        final String id;
        String name;
        String photoUri;

        Player(String id, String name, String photoUri) {
            this.id = id;
            this.name = name;
            this.photoUri = photoUri == null ? "" : photoUri;
        }

        Player copy() {
            return new Player(id, name, photoUri);
        }
    }

    private static class IntCounter {
        int value = 0;
        final int max;
        final TextView view;

        IntCounter(TextView view, int max) {
            this.view = view;
            this.max = Math.max(0, max);
        }

        void inc() {
            if (value < max) value++;
            render();
        }

        void dec() {
            if (value > 0) value--;
            render();
        }

        void render() {
            view.setText(String.valueOf(value));
        }
    }

    private static class BonusCounter {
        int value = 0;
        final int points;
        final TextView view;

        BonusCounter(TextView view, int points) {
            this.view = view;
            this.points = points;
        }

        void inc() { value++; render(); }
        void dec() { if (value > 0) value--; render(); }
        void render() { view.setText(String.valueOf(value)); }
        int total() { return value * points; }
    }

    private static class PlayerInputs {
        final IntCounter bid;
        final IntCounter tricks;
        final BonusCounter pirates;
        final BonusCounter sirens;
        final BonusCounter skull;
        final BonusCounter plus10;
        final BonusCounter plus5;
        final BonusCounter minus5;
        final BonusCounter firstMate;
        final BonusCounter davyJones;

        PlayerInputs(IntCounter bid, IntCounter tricks,
                     BonusCounter pirates, BonusCounter sirens, BonusCounter skull,
                     BonusCounter plus10, BonusCounter plus5, BonusCounter minus5,
                     BonusCounter firstMate, BonusCounter davyJones) {
            this.bid = bid;
            this.tricks = tricks;
            this.pirates = pirates;
            this.sirens = sirens;
            this.skull = skull;
            this.plus10 = plus10;
            this.plus5 = plus5;
            this.minus5 = minus5;
            this.firstMate = firstMate;
            this.davyJones = davyJones;
        }

        double totalBonus() {
            int total = 0;
            if (pirates != null) total += pirates.total();
            if (sirens != null) total += sirens.total();
            if (skull != null) total += skull.total();
            if (plus10 != null) total += plus10.total();
            if (plus5 != null) total += plus5.total();
            if (minus5 != null) total += minus5.total();
            if (firstMate != null) total += firstMate.total();
            if (davyJones != null) total += davyJones.total();
            return total;
        }
    }

    private static class RoundRecord {
        final int roundNumber;
        final int cardsThisRound;
        final List<Double> deltas;

        RoundRecord(int roundNumber, int cardsThisRound, List<Double> deltas) {
            this.roundNumber = roundNumber;
            this.cardsThisRound = cardsThisRound;
            this.deltas = new ArrayList<>(deltas);
        }
    }

    /**
     * Original maritime background drawn directly by the app. The user can replace
     * it with any photo from the phone. It intentionally does not reuse official game art.
     */
    private static class SeaBackgroundView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        SeaBackgroundView(Context context) {
            super(context);
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w = getWidth();
            float h = getHeight();

            LinearGradient sky = new LinearGradient(0, 0, 0, h * 0.72f,
                    new int[]{Color.rgb(112, 159, 162), Color.rgb(47, 93, 105), Color.rgb(12, 43, 58)},
                    null, Shader.TileMode.CLAMP);
            paint.setShader(sky);
            c.drawRect(0, 0, w, h, paint);
            paint.setShader(null);

            // Mist and moon glow.
            paint.setColor(Color.argb(75, 235, 225, 188));
            c.drawCircle(w * 0.72f, h * 0.18f, w * 0.24f, paint);
            paint.setColor(Color.argb(38, 255, 255, 255));
            for (int i = 0; i < 6; i++) {
                float cy = h * (0.14f + i * 0.07f);
                c.drawOval(new RectF(-w * 0.08f, cy, w * 0.92f, cy + h * 0.07f), paint);
            }

            // Ocean.
            LinearGradient ocean = new LinearGradient(0, h * 0.48f, 0, h,
                    new int[]{Color.rgb(16, 74, 85), Color.rgb(4, 43, 57), Color.rgb(2, 24, 39)},
                    null, Shader.TileMode.CLAMP);
            paint.setShader(ocean);
            c.drawRect(0, h * 0.46f, w, h, paint);
            paint.setShader(null);

            // Layered waves.
            for (int layer = 0; layer < 9; layer++) {
                float y = h * (0.50f + layer * 0.055f);
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(2.0f + layer * 0.4f);
                paint.setColor(Color.argb(70 - layer * 4, 198, 239, 235));
                path.reset();
                path.moveTo(0, y);
                for (int x = 0; x <= (int) w; x += Math.max(20, (int) (w / 18))) {
                    float yy = y + (float) Math.sin((x / w) * Math.PI * 7 + layer) * h * 0.008f;
                    path.lineTo(x, yy);
                }
                c.drawPath(path, paint);
            }
            paint.setStyle(Paint.Style.FILL);

            // Stylised tall ship silhouette on the lower right.
            float sx = w * 0.68f;
            float sy = h * 0.67f;
            paint.setColor(Color.argb(175, 2, 17, 25));
            path.reset();
            path.moveTo(sx - w * 0.16f, sy + h * 0.12f);
            path.lineTo(sx + w * 0.18f, sy + h * 0.12f);
            path.lineTo(sx + w * 0.12f, sy + h * 0.18f);
            path.lineTo(sx - w * 0.11f, sy + h * 0.18f);
            path.close();
            c.drawPath(path, paint);

            paint.setStrokeWidth(Math.max(3f, w * 0.007f));
            c.drawRect(sx - w * 0.005f, sy - h * 0.22f, sx + w * 0.005f, sy + h * 0.12f, paint);
            c.drawRect(sx - w * 0.105f, sy - h * 0.12f, sx + w * 0.11f, sy - h * 0.112f, paint);
            c.drawRect(sx - w * 0.085f, sy - h * 0.025f, sx + w * 0.10f, sy - h * 0.017f, paint);

            // Sails.
            paint.setColor(Color.argb(150, 6, 26, 35));
            path.reset();
            path.moveTo(sx - w * 0.005f, sy - h * 0.20f);
            path.lineTo(sx - w * 0.12f, sy - h * 0.12f);
            path.lineTo(sx - w * 0.005f, sy - h * 0.115f);
            path.close();
            c.drawPath(path, paint);
            path.reset();
            path.moveTo(sx + w * 0.008f, sy - h * 0.19f);
            path.lineTo(sx + w * 0.12f, sy - h * 0.12f);
            path.lineTo(sx + w * 0.008f, sy - h * 0.113f);
            path.close();
            c.drawPath(path, paint);
            path.reset();
            path.moveTo(sx - w * 0.004f, sy - h * 0.105f);
            path.lineTo(sx - w * 0.105f, sy - h * 0.025f);
            path.lineTo(sx - w * 0.004f, sy - h * 0.02f);
            path.close();
            c.drawPath(path, paint);
            path.reset();
            path.moveTo(sx + w * 0.007f, sy - h * 0.102f);
            path.lineTo(sx + w * 0.105f, sy - h * 0.025f);
            path.lineTo(sx + w * 0.007f, sy - h * 0.018f);
            path.close();
            c.drawPath(path, paint);

            // Flag.
            paint.setColor(Color.argb(205, 6, 18, 25));
            path.reset();
            path.moveTo(sx, sy - h * 0.22f);
            path.lineTo(sx + w * 0.10f, sy - h * 0.205f);
            path.lineTo(sx, sy - h * 0.18f);
            path.close();
            c.drawPath(path, paint);

            // Dark vignette for legibility.
            paint.setColor(Color.argb(48, 0, 0, 0));
            c.drawRect(0, 0, w, h, paint);
        }
    }
}
